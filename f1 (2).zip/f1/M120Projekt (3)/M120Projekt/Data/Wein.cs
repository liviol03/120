﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace M120Projekt.Data
{
    public class Wein
    {
        #region Datenbankschicht
        [Key]
        public Int64 WeinId { get; set; }
        [Required]
        public String Hersteller { get; set; }
        [Required]
        public String Name { get; set; }
        [Required]
        public DateTime Herstellungsdatum { get; set; }
        [Required]
        public Boolean Empfehlung { get; set; }
        [Required]
        public String Preis { get; set; }
        [Required]
        public String WeinSorte { get; set; }
        [Required]
        public String Kommentar { get; set; }

        #endregion
        #region Applikationsschicht
        public Wein() { }
        [NotMapped]
        public String BerechnetesAttribut
        {
            get
            {
                return "Im Getter kann Code eingefügt werden für berechnete Attribute";
            }
        }
        public static List<Wein> LesenAlle()
        {
            using (var db = new Context())
            {
                return (from record in db.Wein select record).ToList();
            }
        }
        public static Wein LesenID(Int64 weinId)
        {
            using (var db = new Context())
            {
                return (from record in db.Wein where record.WeinId == weinId select record).FirstOrDefault();
            }
        }
        public static List<Wein> LesenAttributGleich(String suchbegriff)
        {
            using (var db = new Context())
            {
                return (from record in db.Wein where record.Name == suchbegriff select record).ToList();
            }
        }
        public static List<Wein> LesenAttributWie(String suchbegriff)
        {
            using (var db = new Context())
            {
                return (from record in db.Wein where record.Name.Contains(suchbegriff) select record).ToList();
            }
        }
        public Int64 Erstellen()
        {
            if (this.Name == null || this.Name == "") this.Name = "leer";
            if (this.Herstellungsdatum == null) this.Herstellungsdatum = DateTime.MinValue;
            using (var db = new Context())
            {
                db.Wein.Add(this);
                db.SaveChanges();
                return this.WeinId;
            }
        }
        public Int64 Aktualisieren()
        {
            using (var db = new Context())
            {
                db.Entry(this).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return this.WeinId;
            }
        }
        public void Loeschen()
        {
            using (var db = new Context())
            {
                db.Entry(this).State = System.Data.Entity.EntityState.Deleted;
                db.SaveChanges();
            }
        }
        public override string ToString()
        {
            return WeinId.ToString(); // Für bessere Coded UI Test Erkennung
        }
        #endregion
    }
}
