﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;

namespace M120Projekt
{
    public partial class Einzelansicht : UserControl
    {
        private UserControl firstWindowContent1;
        private MainWindow mainWindow1;
        private Status status = new Status();
        private Data.Wein wein = new Data.Wein();
        private long weinID;
        private DBAnbindung db = new DBAnbindung();
        private int i = 1;
        public Einzelansicht(MainWindow mainWindow, UserControl firstWindowContent, long weinID, String setenum)
        {
            status.setEnum(setenum);
            this.weinID = weinID;
            if (weinID == 0 && status.checkEnum() == "New")
            {
                this.i = 1;
            }
            else if(weinID > 0 && status.checkEnum() == "Edit")
            {
                this.i = 2;
            }
            else
            {
                this.i = 1;
            }
            this.mainWindow1 = mainWindow;
            this.firstWindowContent1 = firstWindowContent;
            InitializeComponent();
            setValuesCombobox();
            setValues(i);
        }
        
        public void setValuesCombobox()
        {
            WeinSorteAusswahlsBox.Items.Add("Rot Wein");
            WeinSorteAusswahlsBox.Items.Add("Weiss Wein");
        }

        public void setValues(int i)
        {
            if (i == 1)
            {
                DeleteButtonEinzelansicht.IsEnabled = false;
                NameTextBox.Text = "";
                HerstllerTextBox.Text = "";
                PreisTextBox.Text = "";
                HerstellungsDatumTextBox.Text = "";
                KommentarTextBox.Text = "";
            }
            if (i == 2)
            {
                this.wein = Data.Wein.LesenID(weinID);
                DeleteButtonEinzelansicht.IsEnabled = true;
                NameTextBox.Text = wein.Name;
                HerstllerTextBox.Text = wein.Hersteller;
                PreisTextBox.Text = wein.Preis.ToString();
                HerstellungsDatumTextBox.SelectedDate = wein.Herstellungsdatum;
                if (wein.WeinSorte.Equals("Rot Wein"))
                {
                    WeinSorteAusswahlsBox.SelectedItem = "Rot Wein";
                }
                else if (wein.WeinSorte.Equals("Weiss Wein"))
                {
                    WeinSorteAusswahlsBox.SelectedItem = "Weiss Wein";
                }
                if (wein.Empfehlung)
                {
                    ButtonEmpfehlung1.IsChecked = true;
                    ButtonEmpfehlung2.IsChecked = false;
                }
                else
                {
                    ButtonEmpfehlung1.IsChecked = false;
                    ButtonEmpfehlung2.IsChecked = true;
                }
                KommentarTextBox.Text = wein.Kommentar;
            }
        }
        public void saveClicked(object sender, EventArgs e)
        {
            if (validateAll())
            {
                //TODO Empfehlung schauen.
                wein.Name = NameTextBox.Text;
                wein.Hersteller = HerstllerTextBox.Text;
                wein.Preis = PreisTextBox.Text;
                HerstellungsDatumTextBox.SelectedDate = wein.Herstellungsdatum;
                wein.Kommentar = KommentarTextBox.Text;
                if(WeinSorteAusswahlsBox.SelectedItem.Equals("Rot Wein"))
                {
                    wein.WeinSorte = "Rot Wein";
                }else if(WeinSorteAusswahlsBox.SelectedItem.Equals("Weiss Wein"))
                {
                    wein.WeinSorte = "Weiss Wein";
                }
                if (ButtonEmpfehlung1.IsPressed){
                    wein.Empfehlung = true;
                }else{
                    wein.Empfehlung = false;
                }
                status.setEnum("saved");
                db.CreateWein(this.wein);
                GetBack();
            }
            else
            {
                MessageBoxResult result = MessageBox.Show("Du hasst noch nicht alles aussgefüllt");
            }
        }
        public Boolean validateAll()
        {
            if(validateDate() && validateHersteller() && validateName() && validatePreis() == true)
            {
                return true;
            }else
            {
                return false;
            }
        }
        public void GetBack()
        {
            mainWindow1.Lian.Content = firstWindowContent1.Content;
        }
        public void ConformationPopup(object sender, EventArgs e)
        {
            if(status.checkEnum() == "New")
            {
                GetBack();
            }
            else if (status.checkEnum() == "unsaved")
            {
                MessageBoxResult result = MessageBox.Show("Willst du die Änderungen abbrechen?", "", MessageBoxButton.YesNo);
                if (result.Equals(MessageBoxResult.Yes))
                {
                    GetBack();
                }
            }
            else
            {
                MessageBoxResult result = MessageBox.Show("Willst du die Änderungen abbrechen?", "", MessageBoxButton.YesNo);
                if (result.Equals(MessageBoxResult.Yes))
                {
                    GetBack();
                }
            }
        }

        public void OpenDeletePopup(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Willst du den Wein wirklich löschen", "", MessageBoxButton.YesNo);
            if (result.Equals(MessageBoxResult.Yes))
            {
                db.DeleteWein(weinID);
                GetBack();
            }
        }

        private void textChangedEventHandlerName(object sender, TextChangedEventArgs args)
        {
            status.setEnum("unsaved");
            validateName();
        }
        private void textChangedEventHandlerHersteller(object sender, TextChangedEventArgs args)
        {
            status.setEnum("unsaved");
            validateHersteller();
        }
        private void textChangedEventHandlerPreis(object sender, TextChangedEventArgs args)
        {
            status.setEnum("unsaved");
            validatePreis();
        }
        private void textChangedEventHandlerKommentar(object sender, TextChangedEventArgs args)
        {
            status.setEnum("unsaved");
        }
        private void SelectedDateChanged(object sender, CalendarDateChangedEventArgs args)
        {
            status.setEnum("unsaved");
            validateDate();
        }
        
        private bool validateName()
        {
            if (NameTextBox.Text.Equals("") || NameTextBox.Text.Equals(" "))
            {
                NameTextBox.Background = Brushes.Pink;
                return false;
            }
            else
            {
                NameTextBox.Background = Brushes.White;
                return true;
            }
        }
        private bool validateHersteller()
        {
            if (HerstllerTextBox.Text.Equals("") || HerstllerTextBox.Text.Equals(" "))
            {
                HerstllerTextBox.Background = Brushes.Pink;
                return false;
            }
            else
            {
                HerstllerTextBox.Background = Brushes.White;
                return true;
            }
        }
        private bool validatePreis()
        {
            int number;
            if (!int.TryParse(PreisTextBox.Text, out number))
            {
                PreisTextBox.Background = Brushes.Pink;
                return false;
            }
            else
            {
                PreisTextBox.Background = Brushes.White;
                return true;
            }
        }
        private bool validateDate()
        {
            if (HerstellungsDatumTextBox.Text.Equals("") || HerstellungsDatumTextBox.Text.Equals(" "))
            {
                HerstellungsDatumTextBox.Background = Brushes.Pink;
                return false;
            }
            else
            {
                HerstellungsDatumTextBox.Background = Brushes.White;
                return true;
            }
        }
    }
}
