﻿using System;
using System.Diagnostics;

namespace M120Projekt
{
    static class APIDemo
    {
        #region Wein
        // Create
        public static void DemoACreate()
        {
            Debug.Print("--- DemoACreate ---");
            // Wein
            Data.Wein wein1 = new Data.Wein();
            wein1.Hersteller = "Hersteller 1";
            wein1.Preis = "15";
            wein1.Name = "wein 123";
            wein1.Herstellungsdatum = DateTime.Today;
            wein1.WeinSorte = "Rot";
            wein1.Empfehlung = true;
            wein1.Kommentar = "nicht viel";
            Int64 wein1Id = wein1.Erstellen();
            Debug.Print("Artikel erstellt mit Id:" + wein1.WeinId);
        }
        public static void DemoACreateKurz()
        {
            Data.Wein wein2 = new Data.Wein {  Hersteller = "Hersteller 1", Preis = "15", Name = "wein 123", Herstellungsdatum = DateTime.Today, WeinSorte = "Rot", Empfehlung = true, Kommentar = "nicht viel" };
            Int64 wein2Id = wein2.Erstellen();
            Debug.Print("Artikel erstellt mit Id:" + wein2);
        }

        // Read
        public static void DemoARead()
        {
            Debug.Print("--- DemoARead ---");
            // Demo liest alle
            foreach (Data.Wein Wein in Data.Wein.LesenAlle())
            {
                Debug.Print("Artikel Id:" + Wein.WeinId + " Name:" + Wein.Hersteller);
            }
        }
        // Update
        public static void DemoAUpdate()
        {
            Debug.Print("--- DemoAUpdate ---");
            // KlasseA ändert Attribute
            Data.Wein wein1 = Data.Wein.LesenID(1);
            wein1.Name = "Artikel 1 nach Update";
            wein1.Aktualisieren();
        }
        // Delete
        public static void DemoADelete()
        {
            Debug.Print("--- DemoADelete ---");
            Data.Wein.LesenID(2).Loeschen();
            Debug.Print("Artikel mit Id 2 gelöscht");
        }
        #endregion
    }
}
