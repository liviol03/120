﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M120Projekt
{
    public class DBAnbindung
    {
        Status status = new Status();
        public void CreateWein(Data.Wein wein)
        {
            Int64 weinId = wein.Erstellen();
            status.setEnum("Saved");
        }
        public void UpdateWein(Data.Wein wein)
        {
            wein.Aktualisieren();
            status.setEnum("Saved");
        }
        public void DeleteWein(long WeinId)
        {
            Data.Wein.LesenID(WeinId).Loeschen();
            status.setEnum("Saved");
        }
    }
}
