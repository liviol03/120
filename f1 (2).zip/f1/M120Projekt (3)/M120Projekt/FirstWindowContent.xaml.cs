﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace M120Projekt
{
    /// <summary>
    /// Interaktionslogik für FirstWindowContent.xaml
    /// </summary>
    public partial class FirstWindowContent : UserControl
    {
        private MainWindow mainWindow1;
        private Status status = new Status();
        public long WeinId = 0;
        List<Data.Wein> wein;
        DBAnbindung db = new DBAnbindung();
        public FirstWindowContent(MainWindow mainWindow)
        {
            this.mainWindow1 = mainWindow;
            InitializeComponent();
            setWeinListe();
        }

        private void setWeinListe()
        {
            List<Data.Wein> wein2 = this.wein;
            this.wein = Data.Wein.LesenAlle();
            weinList.ItemsSource = wein;
            weinList.CanUserAddRows = false;
            weinList.CanUserSortColumns = true;
            weinList.IsReadOnly = true;
            weinList.SelectionMode = DataGridSelectionMode.Single;
            weinList.AutoGenerateColumns = false;
        }
        public void PageReload(object sender, EventArgs e)
        {
            setWeinListe();
        }
        private void Row_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (weinList.SelectedItem != null)
            {
                Data.Wein wein = (Data.Wein)weinList.SelectedItem;
                EditButton.IsEnabled = true;
                DeleteButton.IsEnabled = true;
                this.WeinId = wein.WeinId;
                OpenEinzelansicht(sender, e, "Edit");
            }
        }

        public void OpenEinzelansicht(object sender, RoutedEventArgs e, String setenum)
        {
            status.setEnum(setenum);
            Einzelansicht einzelansicht = new Einzelansicht(mainWindow1, this, WeinId, setenum);
            mainWindow1.Content = einzelansicht;
        }
        public void changeEnumNew(object sender, RoutedEventArgs e)
        {
            status.setEnum("New");
            OpenEinzelansicht(sender, e, "New");
        }
        public void changeEnumEdit(object sender, RoutedEventArgs e)
        {
            status.setEnum("Edit");
            OpenEinzelansicht(sender, e, "Edit");
        }
        public void OpenDeletePopup(object sender, RoutedEventArgs e)
        {
            setWeinListe();
            MessageBoxResult result = MessageBox.Show("Willst du den Wein wirklich löschen", "", MessageBoxButton.YesNo);
            if (result.Equals(MessageBoxResult.Yes))
            {
                db.DeleteWein(WeinId);
            }
        }
    }
}
