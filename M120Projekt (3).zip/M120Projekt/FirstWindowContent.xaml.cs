﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace M120Projekt
{
    /// <summary>
    /// Interaktionslogik für FirstWindowContent.xaml
    /// </summary>
    public partial class FirstWindowContent : UserControl
    {
        private MainWindow mainWindow1;
        private Status status = new Status();
        public int WeinId;
        List<Data.Wein> wein;
        public FirstWindowContent(MainWindow mainWindow)
        {
            this.mainWindow1 = mainWindow;
            InitializeComponent();

            this.wein = Data.Wein.LesenAlle();
            foreach(Data.Wein i in wein){
                this.WeinAusswahl.Items.Add(i);
            }
        }
        public void OpenEinzelansicht(object sender, RoutedEventArgs e)
        {
            Einzelansicht einzelansicht = new Einzelansicht(mainWindow1, this);
            einzelansicht.setWeinID(WeinId);
            mainWindow1.Content = einzelansicht;
        }

        public void changeEnumNew(object sender, RoutedEventArgs e)
        {
            status.setEnum("New");
            OpenEinzelansicht(sender, e);
        }
        public void changeEnumEdit(object sender, RoutedEventArgs e)
        {
            status.setEnum("Edit");
            this.WeinId = WeinAusswahl.SelectedIndex;

            OpenEinzelansicht(sender, e);
        }
       
        public void OpenDeletePopup(object sender, RoutedEventArgs e)
        {

        }
    }
}
