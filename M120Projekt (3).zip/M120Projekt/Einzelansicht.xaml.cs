﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;

namespace M120Projekt
{
    public partial class Einzelansicht : UserControl
    {
        private UserControl einzelansicht;
        private UserControl firstWindowContent1;
        private MainWindow mainWindow1;
        private Status status = new Status();
        private Data.Wein wein = new Data.Wein();
        private int weinID;
        public Einzelansicht(MainWindow mainWindow, UserControl firstWindowContent)
        {
            this.mainWindow1 = mainWindow;
            this.firstWindowContent1 = firstWindowContent;
            InitializeComponent();
            if (status.checkEnum() == "New")
            {
                setValues(1);
            }else if(status.checkEnum() == "Edit")
            {
                setValues(2);
            }
            else {
                setValuesCombobox();
            }
        }
        public void setValuesCombobox()
        {
            WeinSorteAusswahlsBox.Items.Add("Rot Wein");
            WeinSorteAusswahlsBox.Items.Add("Weiss Wein");
        }

        public void setWeinID(int i)
        {
            weinID = i;
        }

        public void setValues(int i)
        {
            if (i == 1)
            {
                NameTextBox.Text = "";
                HerstllerTextBox.Text = "";
                PreisTextBox.Text = "";
                HerstellungsDatumTextBox.Text = "";
                
                KommentarTextBox.Text = "";
            }
            if (i == 2)
            {
                //daten von DB hollen da Edit
                this.wein = Data.Wein.LesenID(weinID);
                NameTextBox.Text = wein.Name;
                HerstllerTextBox.Text = wein.Hersteller;
                PreisTextBox.Text = wein.Preis.ToString();
                HerstellungsDatumTextBox.SelectedDate = wein.Herstellungsdatum;
                KommentarTextBox.Text = wein.Kommentar;
            }
        }
        public void saveClicked(object sender, EventArgs e)
        {
            if (validateAll())
            {
                //TODO Empfehlung schauen.
                this.wein = Data.Wein.LesenID(weinID);
                wein.Name = NameTextBox.Text;
                wein.Name = HerstllerTextBox.Text;
                wein.Preis = PreisTextBox.Text;
                HerstellungsDatumTextBox.SelectedDate = wein.Herstellungsdatum;
                KommentarTextBox.Text = wein.Kommentar;
                status.setEnum("saved");
                GetBack();
            }
            else
            {
                MessageBoxResult result = MessageBox.Show("Du hasst noch nicht alles aussgefüllt");
            }

        }
        public Boolean validateAll()
        {
            if(validateDate() && validateHersteller() && validateName() && validatePreis() == true)
            {
                return true;
            }else
            {
                return false;
            }
        }
        public void GetBack()
        {
            mainWindow1.Lian.Content = firstWindowContent1.Content;
        }
        public void ConformationPopup(object sender, EventArgs e)
        {
            if(status.checkEnum() == "New")
            {
                Window.GetWindow(einzelansicht).Close();
            }else if (status.checkEnum() == "unsaved")
            {
                MessageBoxResult result = MessageBox.Show("Willst du die Änderungen abbrechen?", "", MessageBoxButton.YesNo);
                if (result.Equals(MessageBoxResult.Yes))
                {
                    Window.GetWindow(einzelansicht).Close();
                }
            }
            else
            {
                MessageBoxResult result = MessageBox.Show("Willst du die Änderungen abbrechen?", "", MessageBoxButton.YesNo);
                if (result.Equals(MessageBoxResult.Yes))
                {
                    GetBack();
                }
            }
        }

        private void textChangedEventHandlerName(object sender, TextChangedEventArgs args)
        {
            status.setEnum("unsaved");
            validateName();
        }
        private void textChangedEventHandlerHersteller(object sender, TextChangedEventArgs args)
        {
            status.setEnum("unsaved");
            validateHersteller();
        }
        private void textChangedEventHandlerPreis(object sender, TextChangedEventArgs args)
        {
            status.setEnum("unsaved");
            validatePreis();
        }
        private void textChangedEventHandlerKommentar(object sender, TextChangedEventArgs args)
        {
            status.setEnum("unsaved");
        }
        private void SelectedDateChanged(object sender, CalendarDateChangedEventArgs args)
        {
            status.setEnum("unsaved");
            validateDate();
        }
        
        private bool validateName()
        {
            if (NameTextBox.Text.Equals("") || NameTextBox.Text.Equals(" "))
            {
                NameTextBox.Background = Brushes.Pink;
                return false;
            }
            else
            {
                NameTextBox.Background = Brushes.White;
                return true;
            }
        }
        private bool validateHersteller()
        {
            if (HerstllerTextBox.Text.Equals("") || HerstllerTextBox.Text.Equals(" "))
            {
                HerstllerTextBox.Background = Brushes.Pink;
                return false;
            }
            else
            {
                HerstllerTextBox.Background = Brushes.White;
                return true;
            }
        }
        private bool validatePreis()
        {
            int number;
            if (!int.TryParse(PreisTextBox.Text, out number))
            {
                PreisTextBox.Background = Brushes.Pink;
                return false;
            }
            else
            {
                PreisTextBox.Background = Brushes.White;
                return true;
            }
        }
        private bool validateDate()
        {
            if (HerstellungsDatumTextBox.Text.Equals("") || HerstellungsDatumTextBox.Text.Equals(" "))
            {
                HerstellungsDatumTextBox.Background = Brushes.Pink;
                return false;
            }
            else
            {
                HerstellungsDatumTextBox.Background = Brushes.White;
                return true;
            }
        }
    }
}
