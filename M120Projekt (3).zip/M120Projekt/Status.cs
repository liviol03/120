﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M120Projekt
{
    public class Status
    {
        public String currentStatusEnum;
        public Status() {
        }
        public void setEnum(String enumType)
        {
            currentStatusEnum = enumType;
        }
        public String checkEnum()
        {
            return currentStatusEnum;
        }
    }
    
}
