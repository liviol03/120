﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M120Projekt
{
    class DBAnbindung
    {
        public void CreateWein(Data.Wein wein)
        {
            Int64 weinId = wein.Erstellen();
        }
        public void UpdateWein(Data.Wein wein)
        {
            wein.Aktualisieren();
        }
        public void DeleteWein(Data.Wein wein)
        {
            Data.Wein.LesenID(wein.WeinId).Loeschen();
        }
    }
}
